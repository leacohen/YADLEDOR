package com.lea.samsung.orledorapp.Inerfaces;

/**
 * Created by USER on 5/8/2016.
 */
public interface IRecommended {
    String get_name();

    String get_link();
}
