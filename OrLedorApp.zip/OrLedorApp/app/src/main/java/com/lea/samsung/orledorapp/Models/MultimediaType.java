package com.lea.samsung.orledorapp.Models;

public enum MultimediaType
{
    Song,
    Movie
}
